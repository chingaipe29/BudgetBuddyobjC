//
//  LoginViewController.h
//  Budget-Buddy
//
//  Created by Mwanda Chipongo on 31/05/2024.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController

@end
