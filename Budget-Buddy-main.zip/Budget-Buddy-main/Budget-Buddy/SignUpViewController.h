//
//  SignUpViewController.h
//  Budget-Buddy
//
//  Created by Mwanda Chipongo on 31/05/2024.
//

#import <UIKit/UIKit.h>

@interface SignUpViewController : UIViewController

@end
